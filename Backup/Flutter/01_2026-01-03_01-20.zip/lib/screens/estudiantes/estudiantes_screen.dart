import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:excel/excel.dart';
import 'dart:io';
import 'dart:ui' as ui;
import '../../models/estudiante.dart';
import '../../providers/anio_lectivo_provider.dart';
import '../../providers/asignatura_provider.dart';
import '../../providers/colegio_provider.dart';
import '../../providers/estudiante_provider.dart';
import '../../providers/grado_provider.dart';
import '../../providers/seccion_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_widgets.dart';
import '../../widgets/dialog_helper.dart';

class EstudiantesScreen extends StatefulWidget {
  const EstudiantesScreen({Key? key}) : super(key: key);

  @override
  State<EstudiantesScreen> createState() => _EstudiantesScreenState();
}

class _EstudiantesScreenState extends State<EstudiantesScreen> {
  final TextEditingController _searchController = TextEditingController();
  final EstudianteProvider _estudianteProvider = EstudianteProvider();

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      _estudianteProvider.cargarEstudiantes();
      context.read<AnioLectivoProvider>().cargarAnios();
      context.read<ColegioProvider>().cargarColegios();
      context.read<AsignaturaProvider>().cargarAsignaturas();
      context.read<GradoProvider>().cargarGrados();
      context.read<SeccionProvider>().cargarSecciones();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showEstudianteDialog({Estudiante? estudiante}) {
    final nombreController = TextEditingController(text: estudiante?.nombre ?? '');
    final apellidoController = TextEditingController(text: estudiante?.apellido ?? '');
    final identidadController = TextEditingController(text: estudiante?.numeroIdentidad ?? '');
    final telefonoController = TextEditingController(text: estudiante?.telefono ?? '');
    final emailController = TextEditingController(text: estudiante?.email ?? '');
    final direccionController = TextEditingController(text: estudiante?.direccion ?? '');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceColor,
        title: Text(
          estudiante == null ? 'Agregar Estudiante' : 'Editar Estudiante',
          style: const TextStyle(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomTextField(
                label: 'Nombre',
                controller: nombreController,
                hint: 'Nombre del estudiante',
              ),
              const SizedBox(height: 12),
              CustomTextField(
                label: 'Apellido',
                controller: apellidoController,
                hint: 'Apellido del estudiante',
              ),
              const SizedBox(height: 12),
              CustomTextField(
                label: 'Número de Identidad',
                controller: identidadController,
                hint: 'Número de identidad (opcional)',
              ),
              const SizedBox(height: 12),
              CustomTextField(
                label: 'Teléfono',
                controller: telefonoController,
                keyboardType: TextInputType.phone,
                hint: 'Teléfono de contacto',
              ),
              const SizedBox(height: 12),
              CustomTextField(
                label: 'Email',
                controller: emailController,
                keyboardType: TextInputType.emailAddress,
                hint: 'Correo electrónico',
              ),
              const SizedBox(height: 12),
              CustomTextField(
                label: 'Dirección',
                controller: direccionController,
                hint: 'Dirección del estudiante',
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancelar',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (nombreController.text.isEmpty || apellidoController.text.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Completa los campos requeridos')),
                );
                return;
              }

              final nuevoEstudiante = Estudiante(
                id: estudiante?.id,
                nombre: nombreController.text,
                apellido: apellidoController.text,
                numeroIdentidad: identidadController.text.isNotEmpty ? identidadController.text : null,
                telefono: telefonoController.text.isNotEmpty ? telefonoController.text : null,
                email: emailController.text.isNotEmpty ? emailController.text : null,
                direccion: direccionController.text.isNotEmpty ? direccionController.text : null,
              );

              if (estudiante == null) {
                _estudianteProvider.crearEstudiante(nuevoEstudiante);
              } else {
                _estudianteProvider.actualizarEstudiante(nuevoEstudiante);
              }

              Navigator.pop(context);
            },
            child: Text(estudiante == null ? 'Agregar' : 'Actualizar'),
          ),
        ],
      ),
    );
  }

  Future<void> _importarDesdeExcel() async {
    try {
      // Solicitar permisos en Android
      if (Platform.isAndroid) {
        final status = await Permission.storage.request();
        if (!status.isGranted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Se necesitan permisos de almacenamiento para importar')),
          );
          return;
        }
      }

      // Abrir selector de archivos
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['xlsx', 'xls'],
        dialogTitle: 'Seleccionar archivo Excel',
      );

      if (result == null) {
        return; // Usuario canceló
      }

      final file = File(result.files.single.path!);
      await _procesarArchivoExcel(file);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al importar: ${e.toString()}')),
      );
    }
  }

  Future<void> _procesarArchivoExcel(File file) async {
    try {
      // Mostrar diálogo de progreso
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          backgroundColor: AppTheme.surfaceColor,
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Procesando archivo Excel...'),
            ],
          ),
        ),
      );

      // Leer el archivo Excel
      final bytes = file.readAsBytesSync();
      final excel = Excel.decodeBytes(bytes);

      // Obtener la primera hoja
      final sheet = excel.tables.values.first;

      // Validar encabezados
      final headers = _obtenerEncabezados(sheet);
      if (!_validarEncabezados(headers)) {
        Navigator.pop(context); // Cerrar diálogo de progreso
        _mostrarErrorEncabezados(headers);
        return;
      }

      // Procesar filas
      final estudiantes = <Estudiante>[];
      final errores = <String>[];

      // Intentar leer filas hasta que no haya más datos
      for (int row = 1; row < 1000; row++) {
        try {
          final estudiante = _crearEstudianteDesdeFila(sheet, row, headers);
          if (estudiante != null) {
            estudiantes.add(estudiante);
          }
        } catch (e) {
          errores.add('Fila ${row + 1}: ${e.toString()}');
        }
        
        // Si no se puede leer más filas, terminar
        try {
          final cell = sheet.cell(CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: row));
          if (cell.value == null) break;
        } catch (e) {
          break;
        }
      }

      Navigator.pop(context); // Cerrar diálogo de progreso

      if (estudiantes.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No se encontraron estudiantes válidos en el archivo')),
        );
        return;
      }

      // Mostrar resumen y confirmar importación
      _mostrarResumenImportacion(estudiantes, errores);

    } catch (e) {
      Navigator.pop(context); // Cerrar diálogo de progreso
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al procesar el archivo: ${e.toString()}')),
      );
    }
  }

  List<String> _obtenerEncabezados(Sheet sheet) {
    final headers = <String>[];
    // Obtener todas las celdas de la primera fila (intentar hasta 20 columnas)
    for (int col = 0; col < 20; col++) {
      try {
        final cell = sheet.cell(CellIndex.indexByColumnRow(columnIndex: col, rowIndex: 0));
        final value = cell.value?.toString() ?? '';
        if (value.isNotEmpty) {
          headers.add(value);
        }
      } catch (e) {
        // Si hay un error, terminamos de leer columnas
        break;
      }
    }
    return headers;
  }

  bool _validarEncabezados(List<String> headers) {
    final requiredHeaders = ['nombre', 'apellido'];
    return requiredHeaders.every((header) => 
      headers.any((h) => h.toLowerCase().trim() == header)
    );
  }

  void _mostrarErrorEncabezados(List<String> headers) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceColor,
        title: const Text('Encabezados incorrectos'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('El archivo debe contener al menos las columnas:'),
            const SizedBox(height: 8),
            const Text('- nombre', style: TextStyle(fontWeight: FontWeight.bold)),
            const Text('- apellido', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Text('Encabezados encontrados: ${headers.join(', ')}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Aceptar'),
          ),
        ],
      ),
    );
  }

  Estudiante? _crearEstudianteDesdeFila(Sheet sheet, int row, List<String> headers) {
    try {
      final nombre = _obtenerValorCelda(sheet, row, headers, 'nombre');
      final apellido = _obtenerValorCelda(sheet, row, headers, 'apellido');
      
      if (nombre == null || apellido == null) {
        return null; // Fila incompleta
      }

      final numeroIdentidad = _obtenerValorCelda(sheet, row, headers, 'numero_identidad');
      final telefono = _obtenerValorCelda(sheet, row, headers, 'telefono');
      final email = _obtenerValorCelda(sheet, row, headers, 'email');
      final direccion = _obtenerValorCelda(sheet, row, headers, 'direccion');

      return Estudiante(
        nombre: nombre,
        apellido: apellido,
        numeroIdentidad: numeroIdentidad,
        telefono: telefono,
        email: email,
        direccion: direccion,
      );
    } catch (e) {
      throw Exception('Error al crear estudiante: ${e.toString()}');
    }
  }

  String? _obtenerValorCelda(Sheet sheet, int row, List<String> headers, String columnName) {
    final columnIndex = headers.indexWhere((h) => h.toLowerCase().trim() == columnName);
    if (columnIndex == -1) return null;

    try {
      final cell = sheet.cell(CellIndex.indexByColumnRow(columnIndex: columnIndex, rowIndex: row));
      final value = cell.value?.toString().trim();
      return value?.isNotEmpty == true ? value : null;
    } catch (e) {
      return null;
    }
  }

  void _mostrarResumenImportacion(List<Estudiante> estudiantes, List<String> errores) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceColor,
        title: const Text('Resumen de Importación'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Estudiantes encontrados: ${estudiantes.length}'),
            if (errores.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Errores: ${errores.length}', style: const TextStyle(color: AppTheme.errorColor)),
              const SizedBox(height: 8),
              ...errores.map((error) => Text(
                error,
                style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
              )).toList(),
            ],
            const SizedBox(height: 16),
            const Text('¿Desea importar estos estudiantes?'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _confirmarImportacion(estudiantes);
            },
            child: const Text('Importar'),
          ),
        ],
      ),
    );
  }

  void _confirmarImportacion(List<Estudiante> estudiantes) async {
    try {
      // Mostrar diálogo de importación
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          backgroundColor: AppTheme.surfaceColor,
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Importando estudiantes...'),
            ],
          ),
        ),
      );

      // Importar estudiantes
      int exitosos = 0;
      int fallidos = 0;

      for (final estudiante in estudiantes) {
        try {
          await _estudianteProvider.crearEstudiante(estudiante);
          exitosos++;
        } catch (e) {
          fallidos++;
        }
      }

      Navigator.pop(context); // Cerrar diálogo de importación

      // Mostrar resultado
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Importación completada: $exitosos exitosos, $fallidos fallidos'
          ),
        ),
      );

      // Recargar lista
      _estudianteProvider.cargarEstudiantes();

    } catch (e) {
      Navigator.pop(context); // Cerrar diálogo de importación
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error durante la importación: ${e.toString()}')),
      );
    }
  }

  List<Estudiante> _filtrarEstudiantes(List<Estudiante> estudiantes) {
    final query = _searchController.text.toLowerCase();
    if (query.isEmpty) return estudiantes;

    return estudiantes.where((estudiante) {
      final nombreCompleto = estudiante.nombreCompleto.toLowerCase();
      final identidad = estudiante.numeroIdentidad?.toLowerCase() ?? '';
      return nombreCompleto.contains(query) || identidad.contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final anioProvider = Provider.of<AnioLectivoProvider>(context);
    final colegioProvider = Provider.of<ColegioProvider>(context);
    final asignaturaProvider = Provider.of<AsignaturaProvider>(context);
    final gradoProvider = Provider.of<GradoProvider>(context);
    final seccionProvider = Provider.of<SeccionProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Estudiantes'),
        elevation: 0,
      ),
      body: Column(
        children: [
          // Filtros
          _buildFilters(anioProvider, colegioProvider, asignaturaProvider, gradoProvider, seccionProvider),
          const SizedBox(height: 16),
          
          // Búsqueda y acciones
          _buildSearchAndActions(),
          const SizedBox(height: 16),
          
          // Lista de estudiantes
          _buildEstudiantesList(),
        ],
      ),
    );
  }

  Widget _buildFilters(
    AnioLectivoProvider anioProvider,
    ColegioProvider colegioProvider,
    AsignaturaProvider asignaturaProvider,
    GradoProvider gradoProvider,
    SeccionProvider seccionProvider,
  ) =>
      Container(
        padding: const EdgeInsets.all(16),
        color: AppTheme.surfaceColor,
        child: Column(
          children: [
            // Fila 1: Año Lectivo y Colegio
            Row(
              children: [
                Expanded(
                  child: _buildDropdown(
                    label: 'Año Lectivo',
                    value: anioProvider.selectedAnio?.nombre ?? 'Seleccionar',
                    items: anioProvider.anios.map((anio) => anio.nombre).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        final selectedAnio = anioProvider.anios.firstWhere(
                          (anio) => anio.nombre == value,
                          orElse: () => anioProvider.anios.first,
                        );
                        anioProvider.seleccionarAnio(selectedAnio);
                      }
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildDropdown(
                    label: 'Colegio',
                    value: colegioProvider.selectedColegio?.nombre ?? 'Seleccionar',
                    items: colegioProvider.colegios.map((colegio) => colegio.nombre).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        final selectedColegio = colegioProvider.colegios.firstWhere(
                          (colegio) => colegio.nombre == value,
                          orElse: () => colegioProvider.colegios.first,
                        );
                        colegioProvider.seleccionarColegio(selectedColegio);
                      }
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Fila 2: Asignatura, Grado y Sección
            Row(
              children: [
                Expanded(
                  child: _buildDropdown(
                    label: 'Asignatura',
                    value: asignaturaProvider.selectedAsignatura?.nombre ?? 'Seleccionar',
                    items: asignaturaProvider.asignaturas.map((asignatura) => asignatura.nombre).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        final selectedAsignatura = asignaturaProvider.asignaturas.firstWhere(
                          (asignatura) => asignatura.nombre == value,
                          orElse: () => asignaturaProvider.asignaturas.first,
                        );
                        asignaturaProvider.seleccionarAsignatura(selectedAsignatura);
                      }
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildDropdown(
                    label: 'Grado',
                    value: gradoProvider.selectedGrado?.nombre ?? 'Seleccionar',
                    items: gradoProvider.grados.map((grado) => grado.nombre).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        final selectedGrado = gradoProvider.grados.firstWhere(
                          (grado) => grado.nombre == value,
                          orElse: () => gradoProvider.grados.first,
                        );
                        gradoProvider.seleccionarGrado(selectedGrado);
                      }
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildDropdown(
                    label: 'Sección',
                    value: seccionProvider.selectedSeccion?.letra ?? 'Seleccionar',
                    items: seccionProvider.secciones.map((seccion) => seccion.letra).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        final selectedSeccion = seccionProvider.secciones.firstWhere(
                          (seccion) => seccion.letra == value,
                          orElse: () => seccionProvider.secciones.first,
                        );
                        seccionProvider.seleccionarSeccion(selectedSeccion);
                      }
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      );

  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) =>
      DropdownButtonFormField<String>(
        initialValue: value != 'Seleccionar' ? value : null,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: AppTheme.cardColor),
          ),
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        ),
        items: items.map((item) => DropdownMenuItem(
            value: item,
            child: Text(item),
          )).toList(),
        onChanged: onChanged,
      );

  Widget _buildSearchAndActions() => Container(
        padding: const EdgeInsets.all(16),
        color: AppTheme.surfaceColor,
        child: Column(
          children: [
            // Búsqueda
            Row(
              children: [
                Expanded(
                  child: CustomTextField(
                    label: 'Buscar estudiante',
                    controller: _searchController,
                    hint: 'Nombre o número de identidad',
                    prefixIcon: const Icon(Icons.search),
                  ),
                ),
                const SizedBox(width: 12),
                IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: _searchController.text.isNotEmpty
                      ? () {
                          _searchController.clear();
                          FocusScope.of(context).unfocus();
                        }
                      : null,
                  color: _searchController.text.isNotEmpty ? AppTheme.primaryColor : AppTheme.textTertiary,
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Acciones
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  onPressed: _showEstudianteDialog,
                  icon: const Icon(Icons.person_add),
                  label: const Text('Agregar Estudiante'),
                ),
                ElevatedButton.icon(
                  onPressed: _importarDesdeExcel,
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Importar Excel'),
                ),
              ],
            ),
          ],
        ),
      );

  Widget _buildEstudiantesList() => Consumer<EstudianteProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading) {
            return const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
              ),
            );
          }

          if (provider.estudiantes.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const EmptyState(
                    message: 'No hay estudiantes registrados',
                    icon: Icons.person,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: _showEstudianteDialog,
                    icon: const Icon(Icons.person_add),
                    label: const Text('Agregar Primer Estudiante'),
                  ),
                ],
              ),
            );
          }

          final estudiantesFiltrados = _filtrarEstudiantes(provider.estudiantes);

          return Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: estudiantesFiltrados.length,
              itemBuilder: (context, index) {
                final estudiante = estudiantesFiltrados[index];
                return CustomCard(
                  onTap: () => provider.seleccionarEstudiante(estudiante),
                  backgroundColor: provider.selectedEstudiante?.id == estudiante.id
                      ? AppTheme.primaryColor.withOpacity(0.2)
                      : AppTheme.surfaceColor,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  estudiante.nombreCompleto,
                                  style: const TextStyle(
                                    color: AppTheme.textPrimary,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                if (estudiante.numeroIdentidad != null)
                                  Text(
                                    'ID: ${estudiante.numeroIdentidad!}',
                                    style: const TextStyle(
                                      color: AppTheme.textSecondary,
                                      fontSize: 12,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          if (provider.selectedEstudiante?.id == estudiante.id)
                            const Icon(
                              Icons.check_circle,
                              color: AppTheme.primaryColor,
                            ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      if (estudiante.telefono != null || estudiante.email != null)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (estudiante.telefono != null)
                              _InfoRow(
                                icon: Icons.phone,
                                label: estudiante.telefono!,
                              ),
                            if (estudiante.email != null)
                              _InfoRow(
                                icon: Icons.email,
                                label: estudiante.email!,
                              ),
                            const SizedBox(height: 8),
                          ],
                        ),
                      if (estudiante.direccion != null)
                        _InfoRow(
                          icon: Icons.location_on,
                          label: estudiante.direccion!,
                        ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit, color: AppTheme.primaryColor),
                            onPressed: () => _showEstudianteDialog(estudiante: estudiante),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete, color: AppTheme.errorColor),
                            onPressed: () {
                              DialogHelper.showDeleteConfirmation(
                                context: context,
                                itemName: estudiante.nombreCompleto,
                                onConfirm: () {
                                  provider.eliminarEstudiante(estudiante.id!);
                                },
                              );
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      );
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.icon,
    required this.label,
  });

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Icon(
            icon,
            size: 16,
            color: AppTheme.textTertiary,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: AppTheme.textTertiary,
                fontSize: 12,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      );
}
