import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/anio_lectivo_provider.dart';
import '../../providers/asignatura_provider.dart';
import '../../providers/corte_evaluativo_provider.dart';
import '../../providers/indicador_evaluacion_provider.dart';
import '../../providers/criterio_evaluacion_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_widgets.dart';

class EvaluacionesScreen extends StatefulWidget {
  const EvaluacionesScreen({Key? key}) : super(key: key);

  @override
  State<EvaluacionesScreen> createState() => _EvaluacionesScreenState();
}

class _EvaluacionesScreenState extends State<EvaluacionesScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  late CorteEvaluativoProvider _corteProvider;
  late IndicadorEvaluacionProvider _indicadorProvider;
  late CriterioEvaluacionProvider _criterioProvider;
  
  // Controladores para los campos de texto de criterios
  final List<TextEditingController> _criterioControllers = List.generate(15, (index) => TextEditingController());
  // Estado para los totales de indicadores
  final List<int> _indicadorTotales = List.filled(5, 20); // 5 indicadores, cada uno con 20 puntos por defecto

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _corteProvider = CorteEvaluativoProvider();
    _indicadorProvider = IndicadorEvaluacionProvider();
    _criterioProvider = CriterioEvaluacionProvider();
    
    // Cargar datos iniciales
    Future.microtask(() {
      _corteProvider.cargarCortes();
      _indicadorProvider.cargarIndicadores();
      _criterioProvider.cargarCriterios();
      // Cargar asignaturas para que estén disponibles en el dropdown
      Provider.of<AsignaturaProvider>(context, listen: false).cargarAsignaturas();
    });
    
    // Configurar controladores con valores por defecto y listeners
    for (int i = 0; i < 15; i++) {
      final int numeroCriterio = (i % 3) + 1;
      final String defaultValue = numeroCriterio == 1 ? '7' : numeroCriterio == 2 ? '7' : '6';
      _criterioControllers[i].text = defaultValue;
      
      _criterioControllers[i].addListener(() {
        _calcularTotalIndicador(i ~/ 3);
      });
    }
  }

  @override
  void dispose() {
    // Limpiar controladores
    for (final controller in _criterioControllers) {
      controller.dispose();
    }
    _tabController.dispose();
    super.dispose();
  }

  void _calcularTotalIndicador(int numeroIndicador) {
    if (numeroIndicador >= 0 && numeroIndicador < _indicadorTotales.length) {
      int total = 0;
      for (int i = 0; i < 3; i++) {
        final index = numeroIndicador * 3 + i;
        if (index < _criterioControllers.length) {
          final text = _criterioControllers[index].text;
          if (text.isNotEmpty) {
            final value = int.tryParse(text) ?? 0;
            total += value;
          }
        }
      }
      
      setState(() {
        _indicadorTotales[numeroIndicador] = total;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final asignaturaProvider = Provider.of<AsignaturaProvider>(context);
    final anioProvider = Provider.of<AnioLectivoProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Evaluaciones'),
        elevation: 0,
      ),
      body: Column(
        children: [
          // Filtros
          _buildFilters(asignaturaProvider, anioProvider),
          const SizedBox(height: 16),
          
          // Pestañas de cortes
          Container(
            color: AppTheme.surfaceColor,
            child: TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: '1er Corte'),
                Tab(text: '2do Corte'),
                Tab(text: '3er Corte'),
                Tab(text: '4to Corte'),
              ],
            ),
          ),
          
          // Contenido de la pestaña seleccionada
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildCorteContent(1),
                _buildCorteContent(2),
                _buildCorteContent(3),
                _buildCorteContent(4),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilters(AsignaturaProvider asignaturaProvider, AnioLectivoProvider anioProvider) => Container(
      padding: const EdgeInsets.all(16),
      color: AppTheme.surfaceColor,
      child: Column(
        children: [
          // Asignatura
          _buildDropdown(
            label: 'Asignatura',
            value: asignaturaProvider.selectedAsignatura?.nombre ?? 'Seleccionar',
            items: asignaturaProvider.asignaturas.map((asignatura) => asignatura.nombre).toList(),
            onChanged: (value) {
              if (value != null) {
                final selectedAsignatura = asignaturaProvider.asignaturas.firstWhere(
                  (asignatura) => asignatura.nombre == value,
                  orElse: () => asignaturaProvider.asignaturas.first,
                );
                asignaturaProvider.seleccionarAsignatura(selectedAsignatura);
              }
            },
          ),
        ],
      ),
    );

  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) => DropdownButtonFormField<String>(
      initialValue: value != 'Seleccionar' ? value : null,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppTheme.cardColor),
        ),
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      ),
      items: items.map((item) => DropdownMenuItem(
          value: item,
          child: Text(item),
        )).toList(),
      onChanged: onChanged,
    );

  Widget _buildCorteContent(int numeroCorte) => Consumer<CorteEvaluativoProvider>(
      builder: (context, corteProvider, _) {
        if (corteProvider.isLoading) {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
            ),
          );
        }

        final asignaturaProvider = Provider.of<AsignaturaProvider>(context);
        final esCualitativa = asignaturaProvider.selectedAsignatura?.cualitativo ?? false;

        if (esCualitativa) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.info_outline,
                    size: 48,
                    color: AppTheme.primaryColor,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Asignatura Cualitativa',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Esta asignatura utiliza evaluación cualitativa.\nNo se requiere el sistema de indicadores y puntos.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: 5, // 5 indicadores por corte
          itemBuilder: (context, indicadorIndex) => _buildIndicadorCard(indicadorIndex + 1, numeroCorte),
        );
      },
    );

  Widget _buildIndicadorCard(int numeroIndicador, int numeroCorte) => ExpansionTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Indicador $numeroIndicador',
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Text(
            '20 puntos',
            style: TextStyle(
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
      children: [
        const SizedBox(height: 8),
        // Criterios del indicador
        _buildCriteriosList(numeroIndicador, numeroCorte),
        const SizedBox(height: 8),
        // Total del indicador
        _buildIndicadorTotal(numeroIndicador),
        const SizedBox(height: 8),
      ],
    );

  Widget _buildCriteriosList(int numeroIndicador, int numeroCorte) => Consumer<CriterioEvaluacionProvider>(
      builder: (context, criterioProvider, _) => Column(
          children: List.generate(3, (criterioIndex) => _buildCriterioInput(criterioIndex + 1, numeroIndicador)),
        ),
    );

  Widget _buildCriterioInput(int numeroCriterio, int numeroIndicador) {
    // Índice del controlador para este criterio específico
    final int controllerIndex = (numeroIndicador - 1) * 3 + (numeroCriterio - 1);
    final TextEditingController controller = _criterioControllers[controllerIndex];
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              'Criterio $numeroCriterio',
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 14,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 1,
            child: CustomTextField(
              label: 'Puntos',
              hint: '0-8',
              keyboardType: TextInputType.number,
              controller: controller,
              onChanged: (value) {
                // El cálculo se maneja automáticamente en el listener del controlador
              },
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            '/ 8',
            style: TextStyle(
              color: AppTheme.textTertiary,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIndicadorTotal(int numeroIndicador) {
    if (numeroIndicador >= 0 && numeroIndicador < _indicadorTotales.length) {
      return Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppTheme.primaryColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Total Indicador:',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '${_indicadorTotales[numeroIndicador]} / 20 puntos',
              style: TextStyle(
                color: _indicadorTotales[numeroIndicador] <= 20 ? AppTheme.primaryColor : AppTheme.errorColor,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    } else {
      return Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppTheme.primaryColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(6),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Total Indicador:',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '0 / 20 puntos',
              style: TextStyle(
                color: AppTheme.primaryColor,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }
  }
}
