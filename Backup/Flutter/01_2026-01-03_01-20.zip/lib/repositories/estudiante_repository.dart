import '../database/database_helper.dart';
import '../models/estudiante.dart';

class EstudianteRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  Future<List<Estudiante>> obtenerTodos() async {
    final db = await _dbHelper.database;
    final maps = await db.query('estudiantes');
    return List.generate(maps.length, (i) => Estudiante.fromMap(maps[i]));
  }

  Future<List<Estudiante>> obtenerActivos() async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'estudiantes',
      where: 'activo = ?',
      whereArgs: [1],
    );
    return List.generate(maps.length, (i) => Estudiante.fromMap(maps[i]));
  }

  Future<Estudiante?> obtenerPorId(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'estudiantes',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) {
      return Estudiante.fromMap(maps.first);
    }
    return null;
  }

  Future<int> crear(Estudiante estudiante) async {
    final db = await _dbHelper.database;
    return db.insert('estudiantes', estudiante.toMap());
  }

  Future<int> actualizar(Estudiante estudiante) async {
    final db = await _dbHelper.database;
    return db.update(
      'estudiantes',
      estudiante.toMap(),
      where: 'id = ?',
      whereArgs: [estudiante.id],
    );
  }

  Future<int> eliminar(int id) async {
    final db = await _dbHelper.database;
    return db.delete(
      'estudiantes',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
