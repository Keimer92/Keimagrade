import 'package:flutter/material.dart';
import '../models/estudiante.dart';
import '../repositories/estudiante_repository.dart';

class EstudianteProvider extends ChangeNotifier {
  final EstudianteRepository _repository = EstudianteRepository();
  List<Estudiante> _estudiantes = [];
  Estudiante? _selectedEstudiante;
  bool _isLoading = false;

  List<Estudiante> get estudiantes => _estudiantes;
  Estudiante? get selectedEstudiante => _selectedEstudiante;
  bool get isLoading => _isLoading;

  Future<void> cargarEstudiantes() async {
    _isLoading = true;
    notifyListeners();
    try {
      _estudiantes = await _repository.obtenerActivos();
      if (_estudiantes.isNotEmpty) {
        _selectedEstudiante = _estudiantes.first;
      } else {
        // Crear estudiantes de prueba si no hay ninguno
        await _crearDatosDePrueba();
        _estudiantes = await _repository.obtenerActivos();
        if (_estudiantes.isNotEmpty) {
          _selectedEstudiante = _estudiantes.first;
        }
      }
    } catch (e) {
      print('Error al cargar estudiantes: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _crearDatosDePrueba() async {
    try {
      final estudiantesPrueba = [
        const Estudiante(
          nombre: 'Juan',
          apellido: 'Pérez',
          numeroIdentidad: '001-123456-1234A',
          telefono: '8888-1111',
          email: 'juan.perez@email.com',
          direccion: 'Barrio Centro, Managua',
        ),
        const Estudiante(
          nombre: 'María',
          apellido: 'González',
          numeroIdentidad: '002-234567-2345B',
          telefono: '8888-2222',
          email: 'maria.gonzalez@email.com',
          direccion: 'Barrio Sarama, Managua',
        ),
        const Estudiante(
          nombre: 'Carlos',
          apellido: 'Ramírez',
          numeroIdentidad: '003-345678-3456C',
          telefono: '8888-3333',
          email: 'carlos.ramirez@email.com',
          direccion: 'Barrio Monseñor Lezcano, Managua',
        ),
        const Estudiante(
          nombre: 'Ana',
          apellido: 'Martínez',
          numeroIdentidad: '004-456789-4567D',
          telefono: '8888-4444',
          email: 'ana.martinez@email.com',
          direccion: 'Barrio San Judas, Managua',
        ),
        const Estudiante(
          nombre: 'José',
          apellido: 'López',
          numeroIdentidad: '005-567890-5678E',
          telefono: '8888-5555',
          email: 'jose.lopez@email.com',
          direccion: 'Barrio Altamira, Managua',
        ),
      ];

      for (final estudiante in estudiantesPrueba) {
        await _repository.crear(estudiante);
      }
    } catch (e) {
      print('Error al crear datos de prueba: $e');
    }
  }

  void seleccionarEstudiante(Estudiante estudiante) {
    _selectedEstudiante = estudiante;
    notifyListeners();
  }

  Future<void> crearEstudiante(Estudiante estudiante) async {
    try {
      await _repository.crear(estudiante);
      await cargarEstudiantes();
    } catch (e) {
      print('Error al crear estudiante: $e');
    }
  }

  Future<void> actualizarEstudiante(Estudiante estudiante) async {
    try {
      await _repository.actualizar(estudiante);
      await cargarEstudiantes();
    } catch (e) {
      print('Error al actualizar estudiante: $e');
    }
  }

  Future<void> eliminarEstudiante(int id) async {
    try {
      await _repository.eliminar(id);
      await cargarEstudiantes();
    } catch (e) {
      print('Error al eliminar estudiante: $e');
    }
  }
}
